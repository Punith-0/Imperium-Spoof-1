"""Run: python -m streamlit run app.py"""
import html
import json
import os
import re
from pathlib import Path
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from analyzer import analyze, AnalysisError
from helpers import load_conversations, load_criteria, fingerprint, report_csv

ROOT=Path(__file__).resolve().parent
load_dotenv(ROOT/'.env')
st.set_page_config(page_title='DynamicIQ · Call Quality',page_icon='🎧',layout='wide')
st.markdown('''<style>
.stApp {background:#f5f7fb;color:#14213d}
[data-testid="stSidebar"] {background:#edf1f8}
[data-testid="stMetric"] {background:white;border:1px solid #dce4ef;border-radius:12px;padding:16px}
h1,h2,h3 {letter-spacing:-.025em}
.turn {border:1px solid #dce4ef;border-radius:10px;padding:12px 16px;margin:8px 0;background:#fff;color:#14213d}
.turn.customer {border-left:4px solid #2563eb}
.turn.agent {border-left:4px solid #10a58a}
.turn.system {border-left:4px solid #e5a334}
.turn small {color:#536782}
mark {background:#ffe69a;color:#1d2939;padding:1px 2px;border-radius:3px}
</style>''',unsafe_allow_html=True)
st.title('DynamicIQ')
st.caption('Call transcript quality review · Team IMPERIUM')

with st.sidebar:
    st.header('Analysis setup')
    mode_label=st.radio('Mode',['Offline demo','AI analysis'])
    mode='demo' if mode_label=='Offline demo' else 'ai'
    key=st.text_input('OpenAI API key',type='password',help='Optional here if configured in .env. Never included in report downloads.') if mode=='ai' else ''
    model=st.text_input('Model',value=os.getenv('OPENAI_MODEL','gpt-4.1-mini')) if mode=='ai' else 'offline_keyword_rules'
    if mode=='ai':
        st.caption('Analyze sends the selected transcript and criteria to OpenAI. API usage may incur charges.')
    else:
        st.info('Offline mode uses keyword rules. It is a UI demo, not an AI quality assessment.')
    st.divider()
    st.subheader('Review requirements')
    st.caption('Review checklist only; these ticks do not alter QA scores.')
    for label in ['Issues and outcomes','Quality checklist','Sentiment changes','Risk flags','Quote evidence','Missing sections']:
        st.checkbox(label,key='req_'+label)
    st.divider()
    st.caption('Limits: 10 MB/file · 500 calls/file · 200 turns and 40,000 characters/call. One call is analyzed at a time.')

with st.expander('Configure quality criteria'):
    criteria_text=st.text_area('Edit checklist JSON',value=(ROOT/'criteria.json').read_text(),height=260)
    st.caption('Weights apply only to assessed pass/fail checks. Unknown and not-applicable results are excluded. Changes here apply to this session.')
    st.download_button('Download criteria',criteria_text,'criteria.json','application/json')
try:
    criteria=load_criteria(criteria_text)
except Exception as e:
    st.error(f'Invalid criteria: {e}');st.stop()

source=st.radio('Transcript source',['Included samples','Upload JSON / CSV / TXT','Paste transcript'],horizontal=True)
try:
    if source=='Included samples':
        calls=load_conversations((ROOT/'samples/mixed_dataset.json').read_bytes(),'mixed_dataset.json')
    elif source=='Upload JSON / CSV / TXT':
        uploaded=st.file_uploader('Choose a transcript or dataset',type=['json','csv','txt'])
        if uploaded is None:
            st.info('Upload your mixed dataset, original ABCD JSON, or a speaker-labelled TXT file.');st.stop()
        calls=load_conversations(uploaded.getvalue(),uploaded.name)
    else:
        pasted=st.text_area('Use Agent: and Customer: labels',height=180,placeholder='Agent: Hello, how can I help?\nCustomer: My refund has not arrived.')
        if not pasted.strip():st.stop()
        calls=load_conversations(pasted.encode(),'pasted_call.txt')
except Exception as e:
    st.error(f'Cannot read input: {e}');st.stop()

index=st.selectbox('Conversation',range(len(calls)),format_func=lambda i:f'{calls[i].conversation_id} · {calls[i].source} · {calls[i].record_type} · {len(calls[i].turns)} turns')
call=calls[index].model_copy(deep=True)
st.caption(f'{len(calls)} conversations loaded. Turn IDs are normalized to t001, t002, … for consistent evidence references.')
# Key includes full input so changing an upload cannot carry a stale completeness confirmation.
input_key=fingerprint(call,criteria,'input','')[:16]
complete=st.checkbox('I confirm this transcript contains the full conversation.',value=call.coverage=='complete',disabled=call.coverage=='incomplete',key='coverage_'+input_key)
if complete and call.coverage!='incomplete':call.coverage='complete'
if call.coverage=='incomplete':st.warning('Missing transcript content detected. Absence-based checks remain unknown.')
for warning in call.warnings:st.caption(warning)
run_key=fingerprint(call,criteria,mode,model)
if 'reports' not in st.session_state:st.session_state.reports={}
if st.button('Analyze conversation',type='primary'):
    with st.spinner('Checking transcript and verifying quote evidence…'):
        try:
            report=analyze(call,criteria,mode,key or os.getenv('OPENAI_API_KEY',''),model)
            # Bounded, per-browser-session storage; no transcript cache shared across users.
            if len(st.session_state.reports)>=10:
                oldest=next(iter(st.session_state.reports));del st.session_state.reports[oldest]
            st.session_state.reports[run_key]=report
        except AnalysisError as e:
            st.error(str(e))
        except Exception:
            st.error('Analysis failed unexpectedly. Check your configuration and retry. No incomplete report was saved.')

report=st.session_state.reports.get(run_key)
if report is None:
    st.info('Select a conversation and click Analyze. Changing criteria, mode or completeness requires a new analysis.')
    with st.expander('Preview transcript',expanded=True):
        st.text('\n'.join(f'[{t.turn_id}] {t.speaker}: {t.text}' for t in call.turns))
    st.stop()

st.subheader('Review dashboard')
st.caption(f'Generated {report["generated_at"]} · {report["model"]}')
for warning in report['warnings']:st.warning(warning)
a=report['analysis']; m=report['metrics']; cols=st.columns(4)
cols[0].metric('QA score',f'{m["score"]} / 100' if m['score'] is not None else 'Not assessed')
cols[1].metric('Checks assessed',f'{m["assessed"]} / {m["eligible"]}')
cols[2].metric('Issues / candidates',len(a['issues']))
cols[3].metric('Risk flags',len(a['risk_flags']))
st.caption('Score covers assessed checks only; unknown and not-applicable checks are excluded. Reviewer decisions are recorded separately and do not silently change the score.')

turn_lookup={t.turn_id:t for t in call.turns}

def evidence_view(evidence):
    if not evidence:
        st.caption('No quoted evidence. Read the explanation and completeness status.')
    for e in evidence:
        st.caption(f'Exact text match · {e["turn_id"]} · {turn_lookup[e["turn_id"]].speaker}')
        st.text(e['quote'])

def review_control(kind,i):
    fid=f'{kind}:{i}'
    # Generated timestamp prevents widget values leaking into a later rerun's new findings.
    widget=f'{run_key}:{report["generated_at"]}:{fid}'
    saved=report['reviews'].get(fid,{})
    options=['pending','accept','reject','needs_review']
    decision=st.selectbox('Reviewer decision',options,index=options.index(saved.get('decision','pending')),key=widget+':decision')
    note=st.text_input('Reviewer note',value=saved.get('notes',''),key=widget+':note')
    report['reviews'][fid]={'decision':decision,'notes':note}

issues_tab,qa_tab,sent_tab,risk_tab,transcript_tab,export_tab=st.tabs(['Issues & outcomes','Quality checks','Sentiment','Risk flags','Transcript & evidence','Review & export'])
with issues_tab:
    if not a['issues']:st.info('No evidence-backed issues were returned. This does not prove the call is issue-free.')
    for i,item in enumerate(a['issues']):
        with st.expander(f'{item["title"]} · {item["outcome"].upper()}',expanded=True):
            st.write(item['explanation']);evidence_view(item['evidence']);review_control('issues',i)
with qa_tab:
    names={c.id:c.name for c in criteria}
    for i,item in enumerate(a['quality_checks']):
        with st.expander(f'{names.get(item["criterion_id"],item["criterion_id"])} · {item["status"].upper()}',expanded=True):
            st.write(item['explanation']);st.caption('Support: '+item['support_type']);evidence_view(item['evidence']);review_control('quality_checks',i)
    st.subheader('Coaching prompts')
    relevant=[q for q in a['quality_checks'] if q['status']=='fail']
    if relevant:
        for q in relevant:st.write('• Review '+names[q['criterion_id']]+': '+q['explanation'])
    else:st.caption('No assessed failing checks. Review unknowns before deciding whether coaching is needed.')
with sent_tab:
    st.caption('Customer turns only. -1 = negative, 0 = neutral, +1 = positive. These are categorical positions, not measured emotional intensity.')
    if a['sentiment']:
        values={'negative':-1,'neutral':0,'positive':1}
        points={s['turn_id']:s for s in a['sentiment']}
        # Null values retain unassessed gaps instead of drawing a false continuous series.
        frame=pd.DataFrame([{'turn':int(t.turn_id[1:]),'sentiment':values[points[t.turn_id]['label']] if t.turn_id in points else None} for t in call.turns if t.speaker=='customer']).set_index('turn')
        st.line_chart(frame)
        st.dataframe(pd.DataFrame([{'turn_id':s['turn_id'],'label':s['label'],'explanation':s['explanation']} for s in a['sentiment']]),width="stretch",hide_index=True)
        for i,s in enumerate(a['sentiment']):
            with st.expander(f'{s["turn_id"]} · {s["label"]}'):
                evidence_view(s['evidence']);review_control('sentiment',i)
    else:st.info('No valid customer sentiment findings.')
with risk_tab:
    if not a['risk_flags']:st.info('No evidence-backed risk flags returned. This is not a compliance certificate.')
    for i,item in enumerate(a['risk_flags']):
        with st.expander(f'{item["severity"].upper()} · {item["title"]}',expanded=True):
            st.write(item['explanation']);evidence_view(item['evidence']);review_control('risk_flags',i)
with transcript_tab:
    st.caption(report['verification_note'])
    options=['All findings']+[f'{kind}:{i}' for kind in ('issues','quality_checks','risk_flags','sentiment') for i in range(len(a[kind]))]
    selected=st.selectbox('Highlight evidence for',options)
    spans=[s for s in report['evidence_offsets'] if selected=='All findings' or s['finding']==selected]
    for t in call.turns:
        intervals=sorted((s['start'],s['end']) for s in spans if s['turn_id']==t.turn_id)
        merged=[]
        for start,end in intervals:
            if merged and start<=merged[-1][1]:merged[-1][1]=max(end,merged[-1][1])
            else:merged.append([start,end])
        pieces=[];cursor=0
        for start,end in merged:
            pieces.extend([html.escape(t.text[cursor:start]),'<mark>'+html.escape(t.text[start:end])+'</mark>']);cursor=end
        pieces.append(html.escape(t.text[cursor:]))
        body=''.join(pieces).replace('\n','<br>')
        st.markdown(f'<div class="turn {t.speaker}"><small>{t.turn_id} · {t.speaker.upper()}</small><br>{body}</div>',unsafe_allow_html=True)
with export_tab:
    report['review_notes']=st.text_area('Overall reviewer notes',value=report.get('review_notes',''),key=run_key+report['generated_at']+':overall')
    st.caption('Session results are kept while this browser session is active. Download to retain your review. Only the last 10 analyses are held in the session.')
    if report['rejected_findings']:
        st.warning(f'{len(report["rejected_findings"])} unsupported findings were withheld.')
        st.dataframe(pd.DataFrame(report['rejected_findings']),width="stretch",hide_index=True)
    safe_name=re.sub(r'[^A-Za-z0-9_.-]','_',call.conversation_id)[:80]
    st.download_button('Download full JSON report',json.dumps(report,indent=2,ensure_ascii=False),f'{safe_name}_report.json','application/json')
    st.download_button('Download findings CSV',report_csv(report),f'{safe_name}_findings.csv','text/csv')
    st.caption('JSON includes transcript, criteria, score, evidence offsets and reviewer decisions. CSV contains one finding per row. Neither export contains your API key.')
